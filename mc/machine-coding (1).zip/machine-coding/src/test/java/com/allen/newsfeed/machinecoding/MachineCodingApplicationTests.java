package com.allen.newsfeed.machinecoding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MachineCodingApplicationTests {

	@Test
	void contextLoads() {
	}

}
