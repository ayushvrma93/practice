package com.twentytwo.designpatterns.decorator;

public interface Pizza {

    String getToppings();
    Double getCost();
}
