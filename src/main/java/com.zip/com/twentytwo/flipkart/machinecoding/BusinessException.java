package com.twentytwo.flipkart.machinecoding;

public class BusinessException extends Exception{

    public BusinessException(){}

    public BusinessException(String message){super(message);}
}
