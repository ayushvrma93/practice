package com.twentytwo.flipkart.machinecoding.notification;

public interface INotificationService {

    void sendMessage();
}
