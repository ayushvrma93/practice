package com.twentytwo.meesho.entity;

public class Buyer extends Person {

    public Buyer(int id, String name, Integer address, String email, String phone) {
        super(id, name, address, email, phone);
    }
}
