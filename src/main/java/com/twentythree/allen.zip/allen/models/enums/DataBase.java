package com.twentythree.allen.models.enums;

public enum DataBase {

    IN_MEMORY;
}
