package com.twentythree.gameberry;

public class Constants {
    public static final int NEW_RESTAURANT_CUTOFF_HOURS = 48;
    public static final int NEW_RESTAURANT_COUNT = 4;
    public static final int NO_OF_RECOMMENDATIONS = 100;
}
