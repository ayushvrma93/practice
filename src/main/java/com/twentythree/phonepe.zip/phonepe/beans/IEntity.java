package com.twentythree.phonepe.beans;

public interface IEntity {
}
