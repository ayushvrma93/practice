package com.twentythree.phonepe.exceptions;

public class BusinessException extends Exception{

    public BusinessException(){}

    public BusinessException(String message){super(message);}
}
