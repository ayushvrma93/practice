package com.twentythree.phonepe;

import com.twentythree.phonepe.beans.User;

import java.util.List;

public interface ISplittingStrategies {

    Float handle(List<User> users, Float amount);
}
